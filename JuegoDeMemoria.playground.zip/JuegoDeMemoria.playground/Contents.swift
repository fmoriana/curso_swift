//: Playground - noun: a place where people can play

import UIKit

//: Playground - noun: a place where people can play

import UIKit

//: Playground - noun: a place where people can play

import UIKit

var rango = [Int]()
var i = 0

for (i=0;i<=100;i++)
{
    rango.append(i)
}

for elemento in rango
{
    if (elemento%5)==0
    {
        print ("# \(elemento) Bingo!!!\n")
    }
    if (elemento%2)==0
    {
        print ("# \(elemento) Par!!!\n")
    }
    if (elemento%2)==1
    {
        print ("# \(elemento) Impar!!!\n")
    }
    if (elemento>=30) && (elemento<=40)
    {
        print ("# \(elemento) Viva Swift!!!\n")
    }
}
