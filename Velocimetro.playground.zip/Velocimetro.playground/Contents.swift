//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int {
    case Apagado=0, VelocidadBaja=20, VelocidadMedia=50, VelocidadAlta=120
    init(velocidadInicial:Velocidades){
        self = velocidadInicial
    }
}

class Auto {
    var velocidad = Velocidades (velocidadInicial:Velocidades.Apagado)
    init ()
    {    
    }
    func cambioVelocidad()-> (actual:Int, velocidadeEnCadena:String){
        var cadenaVelocidad = "Apagado"
        switch self.velocidad {
        case .Apagado:
                self.velocidad = .VelocidadBaja
                cadenaVelocidad = "Velocidad Baja"
        case .VelocidadMedia:
            self.velocidad = .VelocidadAlta
            cadenaVelocidad = "Velocidad Alta"
        default:
            self.velocidad = .VelocidadMedia
            cadenaVelocidad = "Velocidad Media"
        }
        return (self.velocidad.rawValue , cadenaVelocidad)
    }
}

var auto = Auto ()
var i:Int

for (i=0;i<20;i++)
{
    let valoresVelocidad=auto.cambioVelocidad()
    print (valoresVelocidad.actual,",",valoresVelocidad.velocidadeEnCadena)
}


